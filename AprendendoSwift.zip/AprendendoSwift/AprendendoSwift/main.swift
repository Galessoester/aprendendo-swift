//
//  main.swift
//  AprendendoSwift
//
//  Created by Usuário Convidado on 18/03/24.
//

import Foundation

var enf1 = Enfermeira(nome: "Alice", altura: 1.50, mae: true, idade: 21)

var gravida = enf1.estaGravida(mae: enf1.mae)

print("Nome: \(enf1.nome)\nAltura: \(enf1.altura)\nMãe: \(gravida)\nIdade: \(enf1.idade)")

var periodo = "noite"
var pacientes = enf1.contaPacientes(hora: periodo)

print("A enfermeira \(enf1.nome) atenderá \(pacientes) pacientes no período da \(periodo)")

var genero = "M"
var booleano = enf1.generoPaciente(sexo: genero)


