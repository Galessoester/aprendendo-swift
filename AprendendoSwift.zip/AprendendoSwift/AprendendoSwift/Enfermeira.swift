//
//  Enfermeira.swift
//  AprendendoSwift
//
//  Created by Usuário Convidado on 18/03/24.
//

import Cocoa

class Enfermeira: NSObject {
    var nome:String
    var altura:Float
    var mae:Bool
    var idade:Int
    
    init(nome:String, altura:Float, mae:Bool, idade:Int){
        self.nome = nome
        self.altura = altura
        self.mae = mae
        self.idade = idade
    }
    
    func estaGravida(mae:Bool) -> String{
        if mae == false {
            return "Não"
        } else {
            return "Sim"
        }
    }
    
    func contaPacientes(hora:String) -> Int {
        if hora == "manhã" {
            return 10
        }
        if hora == "tarde" {
            return 18
        }
        if hora == "noite"{
            return 8
        }
        return 0
    }
    
    func generoPaciente(sexo:String) -> Bool {
        if sexo == "M" {return false}
        if sexo == "F" {return true}
            return false
    }
    
    
}
